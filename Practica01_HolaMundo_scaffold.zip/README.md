# Práctica 01 – Hola Mundo Interactivo

Proyecto: `practica01`
Package: `com.example.practica01`

## Qué hace esta práctica

1. **FirstScreen**: un campo de texto (`OutlinedTextField`) donde el usuario escribe su
   nombre, y un botón ("Saludar").
2. Al presionar el botón, la app **captura el texto ingresado** y navega a una segunda
   pantalla, pasándole ese texto como argumento.
3. **SecondScreen**: muestra dinámicamente el saludo personalizado ("¡Hola, `<nombre>`!"),
   y además tiene un botón de retorno en la barra superior (esto resuelve el "Reto" del
   material de apoyo).

Este flujo cumple con la consigna: un campo de texto, un botón, una etiqueta, y
actualización dinámica de la pantalla a partir de la entrada del usuario.

## Cómo integrar estos archivos en tu proyecto

1. En Android Studio: **New Project → Empty Activity (Compose)**.
   - Name: `practica01`
   - Package name: `com.example.practica01`
   - Language: Kotlin
   - Minimum SDK: la que estés usando (API 23 o superior está bien)
2. Deja que Gradle sincronice una vez con el proyecto recién creado.
3. Copia los 4 archivos de este ZIP (`MainActivity.kt`, `FirstScreen.kt`,
   `SecondScreen.kt`, `AppNavigator.kt`) dentro de
   `app/src/main/java/com/example/practica01/`, **reemplazando** el `MainActivity.kt`
   que trae por defecto.
4. Abre `app/build.gradle.kts` y agrega esta línea dentro del bloque `dependencies { }`
   (es la única dependencia nueva que necesitas, todo lo demás ya viene en el proyecto
   por defecto):

   ```kotlin
   implementation("androidx.navigation:navigation-compose:2.8.0")
   ```

5. Da clic en **"Sync Now"** cuando Android Studio lo pida.
6. Verifica que en `MainActivity.kt` el nombre del theme importado
   (`Practica01Theme`) coincida con el que Android Studio generó en
   `ui/theme/Theme.kt` (si tu proyecto quedó con otro nombre, ajusta el import).
7. Ejecuta la app en un emulador o dispositivo. Prueba escribir un nombre, dar clic en
   "Saludar" y verificar el saludo dinámico; toma tus capturas de pantalla ahí
   (pantalla inicial y pantalla mostrando el saludo).

## Estructura relevante

```
app/src/main/java/com/example/practica01/
├── MainActivity.kt      # Punto de entrada, monta AppNavigation()
├── AppNavigator.kt      # NavHost: controla el flujo entre pantallas
├── FirstScreen.kt       # Campo de texto + botón (captura del input)
└── SecondScreen.kt      # Etiqueta con el saludo dinámico + botón de retorno
```
