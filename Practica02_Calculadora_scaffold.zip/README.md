# Práctica 02 – Calculadora Básica

Proyecto: `practica02`
Package: `com.example.practica02`

## Qué hace esta práctica

Una calculadora básica construida completamente con Jetpack Compose (sin XML), que
resuelve las 4 operaciones aritméticas (suma, resta, multiplicación, división) y maneja
los casos borde pedidos en la consigna: división entre cero (muestra "Error" sin
colapsar la app) y entradas vacías/nulas (los botones no hacen nada si falta un operando).

## Cómo integrar estos archivos en tu proyecto

1. En Android Studio: **New Project → Empty Activity (Compose)**.
   - Name: `practica02`
   - Package name: `com.example.practica02`
   - Language: Kotlin
2. Deja que Gradle sincronice una vez con el proyecto recién creado.
3. Copia los 3 archivos de este ZIP (`MainActivity.kt`, `PantallaCalc.kt`,
   `LogicaCalc.kt`) dentro de `app/src/main/java/com/example/practica02/`,
   **reemplazando** el `MainActivity.kt` por defecto.
4. No necesitas agregar ninguna dependencia nueva — todo lo usado (Box, Column, Row,
   clickable, clip, background) ya viene incluido en el proyecto Compose por defecto.
5. Ejecuta la app en un emulador o dispositivo. Prueba las 4 operaciones, el botón `C`
   (limpiar), `←` (borrar), `%` (porcentaje), y **una división entre cero** para
   comprobar que muestra "Error" en vez de cerrarse.

## Estructura

```
app/src/main/java/com/example/practica02/
├── MainActivity.kt   # Punto de entrada, monta CalculatorScreen()
├── PantallaCalc.kt   # UI completa: pantalla de resultado + botonera (Box/Column/Row)
└── LogicaCalc.kt     # Objeto singleton con la logica aritmetica (calcular, calcularPorcentaje)
```

## Organización de la interfaz (layouts)

- **Box principal**: centra la calculadora y define el fondo.
- **Column (carcasa)**: agrupa pantalla + botonera con esquinas redondeadas.
- **Box (pantalla)**: muestra `num1 operador num2` alineado a la derecha.
- **Column + Row (botonera)**: 5 filas organizadas con `Arrangement.spacedBy` y
  `Modifier.weight()` para que los botones "C" y "0" sean más anchos que el resto.
- **CalcBtn**: componente reutilizable para no repetir código de cada botón.
